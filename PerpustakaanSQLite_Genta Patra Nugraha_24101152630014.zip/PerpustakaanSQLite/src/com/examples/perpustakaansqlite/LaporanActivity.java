package com.examples.perpustakaansqlite;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;

public class LaporanActivity extends Activity {

    Button btnTampil;
    Spinner spFilter;
    ListView listLaporan;

    DBHelper db;

    ArrayList<String> listData;
    ArrayAdapter<String> adapter;

    // NOTE: sesuaikan dua nilai ini dengan string status yang benar-benar
    // dipakai saat insert di halaman Peminjaman (mis. "Dipinjam" / "Dikembalikan").
    // "Semua" bukan status asli di database, cuma dipakai sebagai pilihan
    // untuk menampilkan semua data tanpa filter.
    private static final String[] FILTER_STATUS = {"Semua", "Dipinjam", "Dikembalikan"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laporan);

        db = new DBHelper(this);

        btnTampil = (Button) findViewById(R.id.btnTampil);
        spFilter = (Spinner) findViewById(R.id.spFilter);
        listLaporan = (ListView) findViewById(R.id.listLaporan);

        // Spinner filter status, wajib ada adapter supaya getSelectedItem() tidak null
        ArrayAdapter<String> adapterFilter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, FILTER_STATUS);
        adapterFilter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFilter.setAdapter(adapterFilter);

        btnTampil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadData();
            }
        });

        // langsung tampilkan semua data begitu halaman dibuka
        loadData();
    }

    void loadData() {

        listData = new ArrayList<String>();

        String filter = spFilter.getSelectedItem() != null
                ? spFilter.getSelectedItem().toString()
                : "Semua";

        Cursor c = db.getLaporanPeminjaman(filter);

        // null check -> hindari NullPointerException kalau query gagal
        if (c != null) {
            try {
                while (c.moveToNext()) {
                    String namaAnggota = c.getString(0);
                    String telepon = c.getString(1);
                    String kelas = c.getString(2);
                    String judulBuku = c.getString(3);
                    String tglPinjam = c.getString(4);
                    String tglKembali = c.getString(5);
                    String status = c.getString(6);

                    String baris =
                            "Nama: " + namaAnggota + "  |  Telp: " + telepon + "  |  Kelas: " + kelas + "\n" +
                            "Buku: " + judulBuku + "\n" +
                            "Pinjam: " + tglPinjam + "   Kembali: " + tglKembali + "   (" + status + ")";

                    listData.add(baris);
                }
            } finally {
                c.close();
            }
        }

        if (listData.isEmpty()) {
            Toast.makeText(this, "Belum ada data peminjaman", Toast.LENGTH_SHORT).show();
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        listLaporan.setAdapter(adapter);
    }
}