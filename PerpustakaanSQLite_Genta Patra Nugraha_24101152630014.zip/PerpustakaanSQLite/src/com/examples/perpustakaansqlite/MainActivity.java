package com.examples.perpustakaansqlite;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    Button btnBuku, btnAnggota, btnPinjam, btnLaporan, btnLogout;
    TextView txtInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBuku = (Button) findViewById(R.id.btnBuku);
        btnAnggota = (Button) findViewById(R.id.btnAnggota);
        btnPinjam = (Button) findViewById(R.id.btnPinjam);
        btnLaporan = (Button) findViewById(R.id.btnLaporan);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        txtInfo = (TextView) findViewById(R.id.txtInfo);

        // FIX (Revisi #3): sapaan nama admin yang sedang login, dikirim dari
        // LoginAdminActivity lewat Intent extra "nama_user"
        String namaUser = getIntent().getStringExtra("nama_user");
        if (!TextUtils.isEmpty(namaUser)) {
            txtInfo.setText("Selamat datang, " + namaUser + " (Admin)");
        } else {
            txtInfo.setText("Dashboard Admin");
        }

        btnBuku.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, BukuActivity.class);
                startActivity(i);
            }
        });

        btnAnggota.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, AnggotaActivity.class);
                startActivity(i);
            }
        });

        btnPinjam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, PeminjamanActivity.class);
                startActivity(i);
            }
        });

        btnLaporan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, LaporanActivity.class);
                startActivity(i);
            }
        });

        // FIX (Revisi #1): Logout mengembalikan ke gerbang pilih role
        // (LoginActivity), bukan cuma finish() ke Activity sebelumnya yang
        // sudah di-finish saat login berhasil.
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, LoginActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                finish();
            }
        });

    }
}
