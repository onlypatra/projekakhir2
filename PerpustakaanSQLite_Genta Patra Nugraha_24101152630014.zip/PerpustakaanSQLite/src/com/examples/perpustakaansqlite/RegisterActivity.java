package com.examples.perpustakaansqlite;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

// FIX (Revisi #1 - Admin dan User harus dipisah):
// Register menentukan role akun (Admin/User) lewat RadioGroup. Sempat ada
// kode registrasi khusus untuk daftar Admin, tapi atas permintaan (biar
// prosesnya nggak ribet pas demo) fitur itu dihapus lagi -- sekarang daftar
// Admin maupun User sama-sama langsung, cuma beda pilihan radio button.
public class RegisterActivity extends Activity {

    EditText edtNama, edtUsername, edtPassword, edtConfirmPassword;
    RadioGroup rgRole;
    RadioButton rbAdmin, rbUser;
    Button btnRegister, btnBack;

    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edtNama = (EditText) findViewById(R.id.edtNama);
        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        edtConfirmPassword = (EditText) findViewById(R.id.edtConfirmPassword);

        rgRole = (RadioGroup) findViewById(R.id.rgRole);
        rbAdmin = (RadioButton) findViewById(R.id.rbAdmin);
        rbUser = (RadioButton) findViewById(R.id.rbUser);

        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnBack = (Button) findViewById(R.id.btnBack);

        db = new DBHelper(this);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nama = edtNama.getText().toString().trim();
                String username = edtUsername.getText().toString().trim();
                String password = edtPassword.getText().toString().trim();
                String confirm = edtConfirmPassword.getText().toString().trim();
                boolean daftarAdmin = rbAdmin.isChecked();

                if (nama.equals("") || username.equals("") || password.equals("") || confirm.equals("")) {
                    Toast.makeText(RegisterActivity.this, "Semua data wajib diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirm)) {
                    Toast.makeText(RegisterActivity.this, "Password tidak sama", Toast.LENGTH_SHORT).show();
                    return;
                }

                // FIX: cek username belum dipakai supaya tidak dobel akun & login ambigu
                if (db.isUsernameTaken(username)) {
                    Toast.makeText(RegisterActivity.this, "Username sudah dipakai, pilih yang lain", Toast.LENGTH_SHORT).show();
                    return;
                }

                String role = daftarAdmin ? "admin" : "user";

                boolean berhasil = db.insertUser(nama, username, password, role);

                if (berhasil) {
                    Toast.makeText(RegisterActivity.this, "Register berhasil, silakan login", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(RegisterActivity.this, "Register gagal", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (db != null) {
            db.close();
        }
        super.onDestroy();
    }
}
