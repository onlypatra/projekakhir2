package com.examples.perpustakaansqlite;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;

public class AnggotaActivity extends Activity {

    EditText edtNama, edtKelas, edtTelepon, edtAlamat;
    Button btnSimpan, btnEdit, btnHapus;
    ListView listAnggota;

    DBHelper db;

    ArrayList<String> listData;
    ArrayList<String> listId; // nyimpen id tiap baris, biar tau row mana yg lagi dipilih
    ArrayAdapter<String> adapter;

    String selectedId = null; // id anggota yang lagi aktif dipilih di listview

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anggota);

        db = new DBHelper(this);

        edtNama = (EditText) findViewById(R.id.edtNama);
        edtKelas = (EditText) findViewById(R.id.edtKelas);
        edtTelepon = (EditText) findViewById(R.id.edtTelepon);
        edtAlamat = (EditText) findViewById(R.id.edtAlamat);

        btnSimpan = (Button) findViewById(R.id.btnSimpan);
        btnEdit = (Button) findViewById(R.id.btnEdit);
        btnHapus = (Button) findViewById(R.id.btnHapus);
        listAnggota = (ListView) findViewById(R.id.listAnggota);

        loadData();

        // simpan anggota baru
        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nama = edtNama.getText().toString().trim();
                String kelas = edtKelas.getText().toString().trim();
                String telepon = edtTelepon.getText().toString().trim();
                String alamat = edtAlamat.getText().toString().trim();

                if (nama.equals("") || kelas.equals("")) {
                    Toast.makeText(AnggotaActivity.this, "Nama sama kelas wajib diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean hasil = db.insertAnggota(nama, kelas, telepon, alamat);

                if (hasil) {
                    Toast.makeText(AnggotaActivity.this, "Data anggota tersimpan", Toast.LENGTH_SHORT).show();
                    clearForm();
                    loadData();
                } else {
                    Toast.makeText(AnggotaActivity.this, "Gagal simpan data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // update data anggota yang lagi dipilih di list
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selectedId == null) {
                    Toast.makeText(AnggotaActivity.this, "Pilih dulu anggotanya di list", Toast.LENGTH_SHORT).show();
                    return;
                }

                String nama = edtNama.getText().toString().trim();
                String kelas = edtKelas.getText().toString().trim();
                String telepon = edtTelepon.getText().toString().trim();
                String alamat = edtAlamat.getText().toString().trim();

                if (nama.equals("") || kelas.equals("")) {
                    Toast.makeText(AnggotaActivity.this, "Nama sama kelas wajib diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean hasil = db.updateAnggota(selectedId, nama, kelas, telepon, alamat);

                if (hasil) {
                    Toast.makeText(AnggotaActivity.this, "Data anggota diupdate", Toast.LENGTH_SHORT).show();
                    clearForm();
                    loadData();
                } else {
                    Toast.makeText(AnggotaActivity.this, "Gagal update data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // hapus data anggota yang lagi dipilih
        btnHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selectedId == null) {
                    Toast.makeText(AnggotaActivity.this, "Pilih dulu anggotanya di list", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean hasil = db.deleteAnggota(selectedId);

                if (hasil) {
                    Toast.makeText(AnggotaActivity.this, "Data anggota dihapus", Toast.LENGTH_SHORT).show();
                    clearForm();
                    loadData();
                } else {
                    Toast.makeText(AnggotaActivity.this, "Gagal hapus data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // klik salah satu baris buat ngisi form otomatis + nandain id-nya
        listAnggota.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                selectedId = listId.get(position);

                String[] pecah = listData.get(position).split(" \\| ");

                edtNama.setText(pecah[0]);
                edtKelas.setText(pecah[1]);
                edtTelepon.setText(pecah[2]);

                // alamat gak ditampilin di list, jadi ambil ulang langsung dari db
                Cursor c = db.getReadableDatabase().rawQuery(
                        "SELECT alamat FROM anggota WHERE id=?", new String[]{selectedId});
                if (c.moveToFirst()) {
                    edtAlamat.setText(c.getString(0));
                }
                c.close();
            }
        });
    }

    void loadData() {

        listData = new ArrayList<String>();
        listId = new ArrayList<String>();

        Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM anggota", null);

        while (c.moveToNext()) {

            listId.add(c.getString(0));

            listData.add(
                    c.getString(1) + " | " +
                    c.getString(2) + " | " +
                    c.getString(3)
            );
        }
        c.close();

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        listAnggota.setAdapter(adapter);
    }

    void clearForm() {
        edtNama.setText("");
        edtKelas.setText("");
        edtTelepon.setText("");
        edtAlamat.setText("");
        selectedId = null;
    }
}