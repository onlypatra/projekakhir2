package com.examples.perpustakaansqlite;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// FIX (Revisi #1): halaman login KHUSUS User, terpisah total dari login Admin
// (lihat LoginAdminActivity). Login dicek ke DBHelper dengan role="user",
// jadi akun Admin tidak bisa dipakai masuk lewat sini.
public class LoginUserActivity extends Activity {

    EditText edtUsername, edtPassword;
    Button btnLogin, btnKembali;

    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_user);

        db = new DBHelper(this);

        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnKembali = (Button) findViewById(R.id.btnKembali);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = edtUsername.getText().toString().trim();
                String password = edtPassword.getText().toString().trim();

                if (username.equals("") || password.equals("")) {
                    Toast.makeText(LoginUserActivity.this, "Username dan password wajib diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (db.checkLogin(username, password, "user")) {
                    Toast.makeText(LoginUserActivity.this, "Login user berhasil", Toast.LENGTH_SHORT).show();

                    String nama = db.getNamaByUsername(username);

                    Intent intent = new Intent(LoginUserActivity.this, UserDashboardActivity.class);
                    intent.putExtra("nama_user", nama);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginUserActivity.this, "Username/password salah atau bukan akun User", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnKembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (db != null) {
            db.close();
        }
        super.onDestroy();
    }
}
