package com.examples.perpustakaansqlite;

import android.app.AlertDialog;
import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;

public class BukuActivity extends Activity {

    EditText edtJudul, edtPenulis, edtPenerbit, edtTahun, edtStok;
    Spinner spKategori;
    Button btnSimpan, btnEdit, btnHapus;
    ListView listBuku;

    DBHelper db;
    ArrayList<String> listData;
    ArrayList<BukuItem> listBukuData;
    ArrayAdapter<String> adapter;

    String selectedId = null; 

    // Model sederhana untuk satu baris data buku hasil query
    private static class BukuItem {
        String id, judul, penulis, penerbit, tahun, kategori;
        int stok;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buku);

        db = new DBHelper(this);

        edtJudul = (EditText) findViewById(R.id.edtJudul);
        edtPenulis = (EditText) findViewById(R.id.edtPenulis);
        edtPenerbit = (EditText) findViewById(R.id.edtPenerbit);
        edtTahun = (EditText) findViewById(R.id.edtTahun);
        edtStok = (EditText) findViewById(R.id.edtStok);
        spKategori = (Spinner) findViewById(R.id.spKategori);
        btnSimpan = (Button) findViewById(R.id.btnSimpan);
        btnEdit = (Button) findViewById(R.id.btnEdit);
        btnHapus = (Button) findViewById(R.id.btnHapus);
        listBuku = (ListView) findViewById(R.id.listBuku);

        // FIX (Revisi #1 - Admin dan User harus dipisah): kalau Activity ini
        // dibuka dari dashboard User (readOnly=true), sembunyikan seluruh
        // form tambah/edit/hapus. User cuma boleh melihat daftar buku.
        boolean readOnly = getIntent().getBooleanExtra("readOnly", false);
        if (readOnly) {
            View scrollFormBuku = findViewById(R.id.scrollFormBuku);
            scrollFormBuku.setVisibility(View.GONE);
        }

        // Spinner kategori wajib punya adapter, kalau tidak
        // getSelectedItem() akan null dan bikin app crash (NullPointerException)
        String[] kategori = {"Fiksi", "Non-Fiksi", "Sains", "Sejarah", "Agama"};
        ArrayAdapter<String> adapterKategori = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, kategori);
        adapterKategori.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spKategori.setAdapter(adapterKategori);

        loadData();

        // SIMPAN
        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                simpanBuku();
            }
        });

        // EDIT (update data yang sedang dipilih dari list)
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editBuku();
            }
        });

        // HAPUS (hapus data yang sedang dipilih dari list)
        btnHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                konfirmasiHapus();
            }
        });

        // Klik salah satu item di list -> isi ke form untuk diedit/dihapus
        listBuku.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pilihBuku(position);
            }
        });
    }

    @Override
    protected void onDestroy() {
        // FIX: koneksi database tidak pernah ditutup sebelumnya -> berpotensi resource leak
        if (db != null) {
            db.close();
        }
        super.onDestroy();
    }

    private boolean validasiInput() {
        String judul = edtJudul.getText().toString().trim();
        String tahun = edtTahun.getText().toString().trim();
        String stokStr = edtStok.getText().toString().trim();

        if (judul.equals("")) {
            Toast.makeText(this, "Judul wajib diisi", Toast.LENGTH_SHORT).show();
            return false;
        }
        // FIX: tahun sebelumnya tidak divalidasi sama sekali (boleh kosong / bukan angka)
        if (!tahun.equals("")) {
            if (!tahun.matches("\\d{4}")) {
                Toast.makeText(this, "Tahun harus berupa 4 digit angka", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        if (stokStr.equals("")) {
            Toast.makeText(this, "Stok wajib diisi", Toast.LENGTH_SHORT).show();
            return false;
        }
        try {
            int stok = Integer.parseInt(stokStr);
            // FIX: sebelumnya stok negatif (mis. "-5") lolos validasi
            if (stok < 0) {
                Toast.makeText(this, "Stok tidak boleh negatif", Toast.LENGTH_SHORT).show();
                return false;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Stok harus berupa angka", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void simpanBuku() {
        if (!validasiInput()) return;

        int stok = Integer.parseInt(edtStok.getText().toString().trim());

        boolean hasil = db.insertBuku(
                edtJudul.getText().toString().trim(),
                edtPenulis.getText().toString().trim(),
                edtPenerbit.getText().toString().trim(),
                edtTahun.getText().toString().trim(),
                spKategori.getSelectedItem().toString(),
                stok
        );

        if (hasil) {
            Toast.makeText(this, "Buku berhasil disimpan", Toast.LENGTH_SHORT).show();
            resetForm();
            loadData();
        } else {
            Toast.makeText(this, "Gagal menyimpan buku", Toast.LENGTH_SHORT).show();
        }
    }

    private void editBuku() {
        if (selectedId == null) {
            Toast.makeText(this, "Pilih dulu data buku dari daftar untuk diedit", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!validasiInput()) return;

        int stok = Integer.parseInt(edtStok.getText().toString().trim());

        boolean hasil = db.updateBuku(
                selectedId,
                edtJudul.getText().toString().trim(),
                edtPenulis.getText().toString().trim(),
                edtPenerbit.getText().toString().trim(),
                edtTahun.getText().toString().trim(),
                spKategori.getSelectedItem().toString(),
                stok
        );

        if (hasil) {
            Toast.makeText(this, "Buku berhasil diupdate", Toast.LENGTH_SHORT).show();
            resetForm();
            loadData();
        } else {
            Toast.makeText(this, "Gagal mengupdate buku", Toast.LENGTH_SHORT).show();
        }
    }

    // FIX: sebelumnya hapus langsung dieksekusi tanpa konfirmasi -> rawan salah pencet/tersentuh
    private void konfirmasiHapus() {
        if (selectedId == null) {
            Toast.makeText(this, "Pilih dulu data buku dari daftar untuk dihapus", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Hapus Buku")
                .setMessage("Yakin ingin menghapus buku \"" + edtJudul.getText().toString().trim() + "\"?")
                .setPositiveButton("Hapus", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        hapusBuku();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void hapusBuku() {
        boolean hasil = db.deleteBuku(selectedId);

        if (hasil) {
            Toast.makeText(this, "Buku berhasil dihapus", Toast.LENGTH_SHORT).show();
            resetForm();
            loadData();
        } else {
            Toast.makeText(this, "Gagal menghapus buku", Toast.LENGTH_SHORT).show();
        }
    }

    private void pilihBuku(int position) {
        // FIX: sebelumnya kode ini menjalankan query ulang ke database (db.getAllBuku())
        // dan mengasumsikan urutan barisnya sama persis dengan saat loadData() dipanggil.
        // Ini boros (query dobel) dan berisiko salah ambil data kalau urutan hasil query
        // berubah. Sekarang cukup ambil dari data yang sudah tersimpan di memori.
        if (listBukuData == null || position < 0 || position >= listBukuData.size()) {
            return;
        }

        BukuItem item = listBukuData.get(position);
        selectedId = item.id;

        edtJudul.setText(item.judul);
        edtPenulis.setText(item.penulis);
        edtPenerbit.setText(item.penerbit);
        edtTahun.setText(item.tahun);

        for (int i = 0; i < spKategori.getCount(); i++) {
            if (spKategori.getItemAtPosition(i).toString().equals(item.kategori)) {
                spKategori.setSelection(i);
                break;
            }
        }
        edtStok.setText(String.valueOf(item.stok));

        btnEdit.setEnabled(true);
        btnHapus.setEnabled(true);
    }

    private void resetForm() {
        selectedId = null;
        edtJudul.setText("");
        edtPenulis.setText("");
        edtPenerbit.setText("");
        edtTahun.setText("");
        edtStok.setText("");
        spKategori.setSelection(0);
    }

    void loadData() {
        listData = new ArrayList<String>();
        listBukuData = new ArrayList<BukuItem>();

        Cursor c = db.getAllBuku();
        // FIX: sebelumnya tidak ada null check, kalau getAllBuku() mengembalikan null
        // (mis. terjadi error di DBHelper) maka c.moveToNext() akan crash NullPointerException
        if (c != null) {
            try {
                while (c.moveToNext()) {
                    BukuItem item = new BukuItem();
                    item.id = c.getString(0);
                    item.judul = c.getString(1);
                    item.penulis = c.getString(2);
                    item.penerbit = c.getString(3);
                    item.tahun = c.getString(4);
                    item.kategori = c.getString(5);
                    item.stok = c.getInt(6);

                    listBukuData.add(item);
                    listData.add(
                            item.judul + " | " +
                            item.penulis + " | " +
                            item.kategori + " | " +
                            item.stok
                    );
                }
            } finally {
                c.close();
            }
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        listBuku.setAdapter(adapter);
    }
}