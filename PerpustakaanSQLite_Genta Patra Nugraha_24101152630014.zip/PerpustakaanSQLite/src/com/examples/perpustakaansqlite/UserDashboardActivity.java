package com.examples.perpustakaansqlite;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

// FIX (Revisi #1 - Admin dan User harus dipisah):
// Dashboard khusus akun User (anggota), terpisah dari MainActivity (dashboard
// Admin). User hanya bisa melihat data (read-only), tidak bisa
// tambah/edit/hapus apa pun.
public class UserDashboardActivity extends Activity {

    Button btnLihatBuku, btnLihatLaporan, btnLogout;
    TextView txtInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        btnLihatBuku = (Button) findViewById(R.id.btnLihatBuku);
        btnLihatLaporan = (Button) findViewById(R.id.btnLihatLaporan);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        txtInfo = (TextView) findViewById(R.id.txtInfo);

        String namaUser = getIntent().getStringExtra("nama_user");
        if (!TextUtils.isEmpty(namaUser)) {
            txtInfo.setText("Selamat datang, " + namaUser + " (User)");
        } else {
            txtInfo.setText("Dashboard User");
        }

        btnLihatBuku.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // FIX: extra "readOnly" membuat BukuActivity menyembunyikan
                // form tambah/edit/hapus, User cuma bisa lihat daftar buku
                Intent i = new Intent(UserDashboardActivity.this, BukuActivity.class);
                i.putExtra("readOnly", true);
                startActivity(i);
            }
        });

        btnLihatLaporan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(UserDashboardActivity.this, LaporanActivity.class);
                startActivity(i);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(UserDashboardActivity.this, LoginActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                finish();
            }
        });
    }
}
