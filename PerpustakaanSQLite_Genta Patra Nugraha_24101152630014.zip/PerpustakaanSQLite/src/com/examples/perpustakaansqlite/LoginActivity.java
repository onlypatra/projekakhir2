package com.examples.perpustakaansqlite;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// FIX (Revisi #1 - Admin dan User harus dipisah, ketika login itu pisah
// halaman, tidak boleh digabung):
// LoginActivity sekarang HANYA jadi halaman gerbang untuk memilih mau masuk
// sebagai Admin atau sebagai User. Form username/password yang dulu ada di
// sini dipindah masing-masing ke LoginAdminActivity dan LoginUserActivity,
// jadi dua halaman & dua alur yang benar-benar terpisah.
public class LoginActivity extends Activity {

    Button btnMasukAdmin, btnMasukUser, btnRegister, btnKeluar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnMasukAdmin = (Button) findViewById(R.id.btnMasukAdmin);
        btnMasukUser = (Button) findViewById(R.id.btnMasukUser);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnKeluar = (Button) findViewById(R.id.btnKeluar);

        btnMasukAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, LoginAdminActivity.class));
            }
        });

        btnMasukUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, LoginUserActivity.class));
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });

        btnKeluar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
