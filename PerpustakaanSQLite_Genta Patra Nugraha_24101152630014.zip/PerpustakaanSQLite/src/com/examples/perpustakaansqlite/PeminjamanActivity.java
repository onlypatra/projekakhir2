package com.examples.perpustakaansqlite;

import android.app.AlertDialog;
import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class PeminjamanActivity extends Activity {

    Spinner spBuku, spAnggota;
    // FIX (Revisi #4): dulu EditText yang diketik manual (rawan salah
    // tahun/format), sekarang TextView yang diisi otomatis oleh aplikasi
    // sesuai tanggal perangkat saat ini.
    TextView edtTglPinjam, edtTglKembali;
    Button btnSimpan, btnEdit, btnHapus, btnKembalikan;
    ListView listPinjam;

    DBHelper db;

    ArrayList<String> listData;
    ArrayList<PeminjamanItem> listPeminjamanData;
    ArrayAdapter<String> adapter;

    ArrayList<String> listJudulBuku, listIdBuku;
    ArrayList<String> listNamaAnggota, listIdAnggota;

    // id peminjaman yang sedang dipilih di list (buat Edit/Hapus)
    String selectedId = null;

    // Model sederhana untuk satu baris data peminjaman hasil query JOIN
    private static class PeminjamanItem {
        String id, idBuku, idAnggota, tglPinjam, tglKembali, status;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peminjaman);

        db = new DBHelper(this);

        spBuku = (Spinner) findViewById(R.id.spBuku);
        spAnggota = (Spinner) findViewById(R.id.spAnggota);

        edtTglPinjam = (TextView) findViewById(R.id.edtTglPinjam);
        edtTglKembali = (TextView) findViewById(R.id.edtTglKembali);

        btnSimpan = (Button) findViewById(R.id.btnSimpan);
        // FIX: btnEdit & btnHapus sudah ada di layout tapi sebelumnya tidak pernah
        // di-findViewById / diberi listener sama sekali, jadi kedua tombol ini
        // kelihatan di layar tapi tidak melakukan apa-apa saat dipencet.
        btnEdit = (Button) findViewById(R.id.btnEdit);
        btnHapus = (Button) findViewById(R.id.btnHapus);
        btnKembalikan = (Button) findViewById(R.id.btnKembalikan);
        listPinjam = (ListView) findViewById(R.id.listPinjam);

        loadSpinnerBuku();
        loadSpinnerAnggota();
        loadData();

        // FIX (Revisi #4): isi tanggal pinjam & kembali otomatis begitu
        // halaman dibuka, sesuai tanggal/hari/bulan/tahun perangkat saat ini.
        setTanggalOtomatis();

        // simpan data peminjaman baru
        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (listIdBuku.isEmpty() || listIdAnggota.isEmpty()) {
                    Toast.makeText(PeminjamanActivity.this,
                            "Data buku atau anggota masih kosong, isi dulu ya", Toast.LENGTH_SHORT).show();
                    return;
                }

                String idBuku = listIdBuku.get(spBuku.getSelectedItemPosition());
                String idAnggota = listIdAnggota.get(spAnggota.getSelectedItemPosition());
                String tglPinjam = edtTglPinjam.getText().toString().trim();
                String tglKembali = edtTglKembali.getText().toString().trim();

                if (tglPinjam.equals("")) {
                    Toast.makeText(PeminjamanActivity.this, "Tanggal pinjam wajib diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                // FIX: cek dulu stok buku sebelum simpan, supaya pesan errornya jelas
                // ("stok habis") dan tidak sekadar "gagal simpan" yang membingungkan.
                // Pengurangan stok yang sesungguhnya tetap dilakukan atomik di dalam
                // db.insertPeminjaman() (lihat DBHelper), jadi tetap aman walau
                // pengecekan di sini dan insert-nya terpisah.
                if (db.getStokBuku(idBuku) <= 0) {
                    Toast.makeText(PeminjamanActivity.this,
                            "Stok buku ini sudah habis, tidak bisa dipinjam", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean hasil = db.insertPeminjaman(idBuku, idAnggota, tglPinjam, tglKembali, "Dipinjam");

                if (hasil) {
                    Toast.makeText(PeminjamanActivity.this, "Data peminjaman tersimpan", Toast.LENGTH_SHORT).show();
                    resetForm();
                    loadData();
                } else {
                    Toast.makeText(PeminjamanActivity.this, "Gagal simpan data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // FIX: baru sekarang tombol EDIT benar-benar melakukan update ke database
        // lewat db.updatePeminjaman(), yang sebelumnya sudah tersedia di DBHelper
        // tapi tidak pernah dipanggil dari sini.
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selectedId == null) {
                    Toast.makeText(PeminjamanActivity.this,
                            "Pilih dulu data peminjaman dari daftar untuk diedit", Toast.LENGTH_SHORT).show();
                    return;
                }

                String idBuku = listIdBuku.get(spBuku.getSelectedItemPosition());
                String idAnggota = listIdAnggota.get(spAnggota.getSelectedItemPosition());
                String tglPinjam = edtTglPinjam.getText().toString().trim();
                String tglKembali = edtTglKembali.getText().toString().trim();

                if (tglPinjam.equals("")) {
                    Toast.makeText(PeminjamanActivity.this, "Tanggal pinjam wajib diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                // status peminjaman yang sedang diedit tetap dipertahankan (tidak diubah dari sini)
                String statusSekarang = "Dipinjam";
                String idBukuLama = null;
                for (PeminjamanItem item : listPeminjamanData) {
                    if (item.id.equals(selectedId)) {
                        statusSekarang = item.status;
                        idBukuLama = item.idBuku;
                        break;
                    }
                }

                // FIX: kalau buku yang dipinjam diganti sementara statusnya masih
                // "Dipinjam", cek dulu stok buku pengganti supaya pesan errornya jelas
                // (db.updatePeminjaman() juga mengecek ulang ini secara atomik)
                if (statusSekarang.equals("Dipinjam") && idBukuLama != null && !idBukuLama.equals(idBuku)) {
                    if (db.getStokBuku(idBuku) <= 0) {
                        Toast.makeText(PeminjamanActivity.this,
                                "Stok buku pengganti sudah habis", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                boolean hasil = db.updatePeminjaman(selectedId, idBuku, idAnggota, tglPinjam, tglKembali, statusSekarang);

                if (hasil) {
                    Toast.makeText(PeminjamanActivity.this, "Data peminjaman diupdate", Toast.LENGTH_SHORT).show();
                    resetForm();
                    loadData();
                } else {
                    Toast.makeText(PeminjamanActivity.this, "Gagal update data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // FIX: baru sekarang tombol HAPUS benar-benar menghapus data lewat
        // db.deletePeminjaman(), sekaligus ditambah dialog konfirmasi supaya
        // konsisten dengan pola konfirmasi hapus yang sudah ada di BukuActivity.
        btnHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                konfirmasiHapus();
            }
        });

        // FIX: ditambahkan supaya ada cara nyata menandai buku sudah dikembalikan.
        // Sebelumnya db.updateStatusPeminjaman() sudah ada di DBHelper tapi tidak
        // pernah dipanggil dari layar manapun, jadi status selamanya "Dipinjam"
        // dan stok buku tidak pernah kembali.
        btnKembalikan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selectedId == null) {
                    Toast.makeText(PeminjamanActivity.this,
                            "Pilih dulu data peminjaman dari daftar", Toast.LENGTH_SHORT).show();
                    return;
                }

                String statusSekarang = null;
                for (PeminjamanItem item : listPeminjamanData) {
                    if (item.id.equals(selectedId)) {
                        statusSekarang = item.status;
                        break;
                    }
                }

                if ("Dikembalikan".equals(statusSekarang)) {
                    Toast.makeText(PeminjamanActivity.this,
                            "Buku ini sudah tercatat dikembalikan", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean hasil = db.updateStatusPeminjaman(selectedId, "Dikembalikan");

                if (hasil) {
                    Toast.makeText(PeminjamanActivity.this,
                            "Buku ditandai dikembalikan, stok bertambah", Toast.LENGTH_SHORT).show();
                    resetForm();
                    loadData();
                } else {
                    Toast.makeText(PeminjamanActivity.this, "Gagal menandai pengembalian", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // FIX: sebelumnya listPinjam tidak punya OnItemClickListener sama sekali,
        // jadi selectedId tidak pernah terisi dan tombol Edit/Hapus tidak mungkin
        // tahu baris mana yang mau diubah/dihapus.
        listPinjam.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pilihPeminjaman(position);
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (db != null) {
            db.close();
        }
        super.onDestroy();
    }

    private void konfirmasiHapus() {
        if (selectedId == null) {
            Toast.makeText(this, "Pilih dulu data peminjaman dari daftar untuk dihapus", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Hapus Peminjaman")
                .setMessage("Yakin ingin menghapus data peminjaman ini?")
                .setPositiveButton("Hapus", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        hapusPeminjaman();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void hapusPeminjaman() {
        boolean hasil = db.deletePeminjaman(selectedId);

        if (hasil) {
            Toast.makeText(this, "Data peminjaman dihapus", Toast.LENGTH_SHORT).show();
            resetForm();
            loadData();
        } else {
            Toast.makeText(this, "Gagal menghapus data peminjaman", Toast.LENGTH_SHORT).show();
        }
    }

    // isi form + spinner sesuai baris peminjaman yang diklik di list
    private void pilihPeminjaman(int position) {
        if (listPeminjamanData == null || position < 0 || position >= listPeminjamanData.size()) {
            return;
        }

        PeminjamanItem item = listPeminjamanData.get(position);
        selectedId = item.id;

        int posBuku = listIdBuku.indexOf(item.idBuku);
        if (posBuku >= 0) {
            spBuku.setSelection(posBuku);
        }

        int posAnggota = listIdAnggota.indexOf(item.idAnggota);
        if (posAnggota >= 0) {
            spAnggota.setSelection(posAnggota);
        }

        edtTglPinjam.setText(item.tglPinjam);
        edtTglKembali.setText(item.tglKembali);
    }

    private void resetForm() {
        selectedId = null;
        // FIX (Revisi #4): balik ke tanggal otomatis hari ini, bukan dikosongkan
        setTanggalOtomatis();
        if (spBuku.getCount() > 0) spBuku.setSelection(0);
        if (spAnggota.getCount() > 0) spAnggota.setSelection(0);
    }

    // FIX (Revisi #4 - Tanggal & tahun peminjaman/pengembalian harus sesuai
    // tanggal sekarang): isi Tanggal Pinjam = hari ini, Tanggal Kembali =
    // hari ini + 7 hari (jatuh tempo default), memakai format dd-MM-yyyy
    // sama seperti pola setTanggalOtomatis() di contoh Apotek Sehat.
    private void setTanggalOtomatis() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

        Calendar calPinjam = Calendar.getInstance();
        edtTglPinjam.setText(sdf.format(calPinjam.getTime()));

        Calendar calKembali = Calendar.getInstance();
        calKembali.add(Calendar.DAY_OF_MONTH, 7);
        edtTglKembali.setText(sdf.format(calKembali.getTime()));
    }

    // isi spinner buku dari tabel buku
    void loadSpinnerBuku() {

        listJudulBuku = new ArrayList<String>();
        listIdBuku = new ArrayList<String>();

        Cursor c = db.getAllBuku();

        while (c.moveToNext()) {
            listIdBuku.add(c.getString(0));
            listJudulBuku.add(c.getString(1));
        }
        c.close();

        ArrayAdapter<String> adapterBuku = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, listJudulBuku);
        adapterBuku.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBuku.setAdapter(adapterBuku);
    }

    // isi spinner anggota dari tabel anggota
    void loadSpinnerAnggota() {

        listNamaAnggota = new ArrayList<String>();
        listIdAnggota = new ArrayList<String>();

        Cursor c = db.getAllAnggota();

        while (c.moveToNext()) {
            listIdAnggota.add(c.getString(0));
            listNamaAnggota.add(c.getString(1));
        }
        c.close();

        ArrayAdapter<String> adapterAnggota = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, listNamaAnggota);
        adapterAnggota.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spAnggota.setAdapter(adapterAnggota);
    }

    void loadData() {

        listData = new ArrayList<String>();
        listPeminjamanData = new ArrayList<PeminjamanItem>();

        // pake query JOIN dari DBHelper biar yang muncul judul buku & nama anggota, bukan cuma id
        // kolom: 0=id, 1=judul, 2=nama, 3=tanggal_pinjam, 4=tanggal_kembali, 5=status, 6=id_buku, 7=id_anggota
        Cursor c = db.getAllPeminjaman();

        // FIX: tambahkan null check, sama seperti di BukuActivity/LaporanActivity,
        // supaya tidak crash NullPointerException kalau query gagal
        if (c != null) {
            try {
                while (c.moveToNext()) {

                    PeminjamanItem item = new PeminjamanItem();
                    item.id = c.getString(0);
                    item.tglPinjam = c.getString(3);
                    item.tglKembali = c.getString(4);
                    item.status = c.getString(5);
                    item.idBuku = c.getString(6);
                    item.idAnggota = c.getString(7);
                    listPeminjamanData.add(item);

                    listData.add(
                            c.getString(1) + " | " +
                            c.getString(2) + " | " +
                            c.getString(5)
                    );
                }
            } finally {
                c.close();
            }
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
        listPinjam.setAdapter(adapter);
    }
}