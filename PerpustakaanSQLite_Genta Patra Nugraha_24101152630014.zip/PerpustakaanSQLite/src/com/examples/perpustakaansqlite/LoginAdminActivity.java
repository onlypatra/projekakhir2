package com.examples.perpustakaansqlite;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// FIX (Revisi #1): halaman login KHUSUS Admin, terpisah total dari login User
// (lihat LoginUserActivity). Login dicek ke DBHelper dengan role="admin",
// jadi akun yang didaftarkan sebagai "user" tidak akan bisa masuk lewat sini.
public class LoginAdminActivity extends Activity {

    EditText edtUsername, edtPassword;
    Button btnLogin, btnKembali;

    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_admin);

        db = new DBHelper(this);

        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnKembali = (Button) findViewById(R.id.btnKembali);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = edtUsername.getText().toString().trim();
                String password = edtPassword.getText().toString().trim();

                if (username.equals("") || password.equals("")) {
                    Toast.makeText(LoginAdminActivity.this, "Username dan password wajib diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (db.checkLogin(username, password, "admin")) {
                    Toast.makeText(LoginAdminActivity.this, "Login admin berhasil", Toast.LENGTH_SHORT).show();

                    String nama = db.getNamaByUsername(username);

                    Intent intent = new Intent(LoginAdminActivity.this, MainActivity.class);
                    intent.putExtra("nama_user", nama);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginAdminActivity.this, "Username/password salah atau bukan akun Admin", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnKembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (db != null) {
            db.close();
        }
        super.onDestroy();
    }
}
