package com.examples.perpustakaansqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "perpusku.db";
    // FIX (Revisi #1 - Admin & User harus dipisah): naikkan versi karena tabel
    // user sekarang punya kolom baru "role" (admin / user)
    private static final int DB_VERSION = 2;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // TABEL USER (LOGIN / REGISTER)
        // FIX (Revisi #1): tambah kolom "role" ("admin" / "user") supaya akun
        // Admin (petugas) dan User (anggota) benar-benar terpisah datanya,
        // bukan cuma dibedakan dari tampilan saja.
        db.execSQL(
                "CREATE TABLE user (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "nama TEXT," +
                        "username TEXT," +
                        "password TEXT," +
                        "role TEXT)"
        );

        // TABEL BUKU
        db.execSQL(
                "CREATE TABLE buku (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "judul TEXT," +
                        "penulis TEXT," +
                        "penerbit TEXT," +
                        "tahun TEXT," +
                        "kategori TEXT," +
                        "stok INTEGER)"
        );

        // TABEL ANGGOTA
        db.execSQL(
                "CREATE TABLE anggota (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "nama TEXT," +
                        "kelas TEXT," +
                        "telepon TEXT," +
                        "alamat TEXT)"
        );

        // TABEL PEMINJAMAN
        db.execSQL(
                "CREATE TABLE peminjaman (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "id_buku INTEGER," +
                        "id_anggota INTEGER," +
                        "tanggal_pinjam TEXT," +
                        "tanggal_kembali TEXT," +
                        "status TEXT)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS buku");
        db.execSQL("DROP TABLE IF EXISTS anggota");
        db.execSQL("DROP TABLE IF EXISTS peminjaman");

        onCreate(db);
    }

    // LOGIN CHECK
    // FIX (Revisi #1): login sekarang WAJIB menyertakan role ("admin"/"user")
    // supaya akun admin tidak bisa nyelonong login lewat halaman Login User,
    // begitu juga sebaliknya. Login Admin dan Login User dipisah jadi 2
    // Activity & 2 layout yang berbeda (lihat LoginAdminActivity & LoginUserActivity).
    public boolean checkLogin(String username, String password, String role) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM user WHERE username=? AND password=? AND role=?",
                new String[]{username, password, role}
        );

        boolean result = cursor.getCount() > 0;
        cursor.close();

        return result;
    }

    // ambil nama lengkap user berdasarkan username, dipakai untuk sapaan
    // "Selamat datang, <nama>" di dashboard Admin maupun User
    public String getNamaByUsername(String username) {

        SQLiteDatabase db = this.getReadableDatabase();
        String nama = username;

        Cursor cursor = db.rawQuery("SELECT nama FROM user WHERE username=?", new String[]{username});
        if (cursor.moveToFirst()) {
            nama = cursor.getString(0);
        }
        cursor.close();

        return nama;
    }

    // INSERT USER (REGISTER)
    // FIX (Revisi #1): sekarang menyimpan role juga ("admin" atau "user")
    public boolean insertUser(String nama, String username, String password, String role) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("nama", nama);
        cv.put("username", username);
        cv.put("password", password);
        cv.put("role", role);

        long hasil = db.insert("user", null, cv);

        return hasil != -1;
    }

    // cek apakah username sudah dipakai (dipakai saat Register supaya tidak dobel)
    public boolean isUsernameTaken(String username) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT id FROM user WHERE username=?", new String[]{username});
        boolean taken = cursor.getCount() > 0;
        cursor.close();

        return taken;
    }

    // CRUD BUKU
    public boolean insertBuku(String judul, String penulis, String penerbit, String tahun, String kategori, int stok) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("judul", judul);
        cv.put("penulis", penulis);
        cv.put("penerbit", penerbit);
        cv.put("tahun", tahun);
        cv.put("kategori", kategori);
        cv.put("stok", stok);

        long hasil = db.insert("buku", null, cv);

        return hasil != -1;
    }

    public Cursor getAllBuku() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery("SELECT * FROM buku", null);
    }

    public boolean updateBuku(String id, String judul, String penulis, String penerbit, String tahun, String kategori, int stok) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("judul", judul);
        cv.put("penulis", penulis);
        cv.put("penerbit", penerbit);
        cv.put("tahun", tahun);
        cv.put("kategori", kategori);
        cv.put("stok", stok);

        int hasil = db.update("buku", cv, "id=?", new String[]{id});

        return hasil > 0;
    }

    public boolean deleteBuku(String id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int hasil = db.delete("buku", "id=?", new String[]{id});

        return hasil > 0;
    }

    // CRUD ANGGOTA
    public boolean insertAnggota(String nama, String kelas, String telepon, String alamat) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("nama", nama);
        cv.put("kelas", kelas);
        cv.put("telepon", telepon);
        cv.put("alamat", alamat);

        long hasil = db.insert("anggota", null, cv);

        return hasil != -1;
    }

    public Cursor getAllAnggota() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery("SELECT * FROM anggota", null);
    }

    public boolean updateAnggota(String id, String nama, String kelas, String telepon, String alamat) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("nama", nama);
        cv.put("kelas", kelas);
        cv.put("telepon", telepon);
        cv.put("alamat", alamat);

        int hasil = db.update("anggota", cv, "id=?", new String[]{id});

        return hasil > 0;
    }

    public boolean deleteAnggota(String id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int hasil = db.delete("anggota", "id=?", new String[]{id});

        return hasil > 0;
    }

    // CRUD PEMINJAMAN

    // helper internal: ambil stok terkini di dalam transaksi yang sedang berjalan
    private int getStokDalamTransaksi(SQLiteDatabase db, String idBuku) {
        int stok = 0;
        Cursor c = db.rawQuery("SELECT stok FROM buku WHERE id=?", new String[]{idBuku});
        if (c.moveToFirst()) {
            stok = c.getInt(0);
        }
        c.close();
        return stok;
    }

    // dipakai UI buat cek dulu sebelum submit, supaya bisa kasih pesan yang jelas
    // ("stok habis") daripada cuma "gagal simpan" yang bikin bingung
    public int getStokBuku(String idBuku) {
        SQLiteDatabase db = this.getReadableDatabase();
        return getStokDalamTransaksi(db, idBuku);
    }

    // FIX: sebelumnya insertPeminjaman() cuma mencatat transaksi peminjaman ke
    // tabel peminjaman, TIDAK PERNAH mengurangi stok di tabel buku. Akibatnya
    // satu buku bisa terus-terusan "dipinjam" walau stoknya sudah 0.
    // Sekarang insert + kurangi stok digabung jadi satu transaksi atomik:
    // kalau stok ternyata habis (dicek ulang di sini juga, bukan cuma di UI)
    // atau salah satu langkah gagal, semuanya dibatalkan (rollback) supaya
    // datanya tidak pernah nyangkut setengah jalan.
    public boolean insertPeminjaman(String idBuku, String idAnggota, String tglPinjam, String tglKembali, String status) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            int stok = getStokDalamTransaksi(db, idBuku);
            if (stok <= 0) {
                return false; // stok habis, batal dipinjam
            }

            ContentValues cvPinjam = new ContentValues();
            cvPinjam.put("id_buku", idBuku);
            cvPinjam.put("id_anggota", idAnggota);
            cvPinjam.put("tanggal_pinjam", tglPinjam);
            cvPinjam.put("tanggal_kembali", tglKembali);
            cvPinjam.put("status", status);
            long hasilInsert = db.insert("peminjaman", null, cvPinjam);
            if (hasilInsert == -1) {
                return false;
            }

            ContentValues cvStok = new ContentValues();
            cvStok.put("stok", stok - 1);
            int hasilStok = db.update("buku", cvStok, "id=?", new String[]{idBuku});
            if (hasilStok <= 0) {
                return false;
            }

            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }

    // ambil data peminjaman lengkap sama judul buku & nama anggota (biar gak nampilin id doang)
    // FIX: ditambahkan peminjaman.id_buku & peminjaman.id_anggota di akhir SELECT (kolom index 6 & 7)
    // supaya form Edit bisa tau id_buku/id_anggota asli buat set pilihan Spinner,
    // tanpa mengubah urutan kolom 0-5 yang sudah dipakai di tempat lain (loadData di PeminjamanActivity, laporan, dll)
    public Cursor getAllPeminjaman() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT peminjaman.id, buku.judul, anggota.nama, peminjaman.tanggal_pinjam, " +
                        "peminjaman.tanggal_kembali, peminjaman.status, " +
                        "peminjaman.id_buku, peminjaman.id_anggota " +
                        "FROM peminjaman " +
                        "JOIN buku ON peminjaman.id_buku = buku.id " +
                        "JOIN anggota ON peminjaman.id_anggota = anggota.id " +
                        "ORDER BY peminjaman.id DESC",
                null
        );
    }

    // LAPORAN PEMINJAMAN LENGKAP
    // Menampilkan: nama anggota, no telp, kelas, judul buku, tanggal pinjam, tanggal kembali, status
    // statusFilter: "Semua" (atau null) -> tampilkan semua data,
    //               selain itu -> filter WHERE peminjaman.status = statusFilter
    public Cursor getLaporanPeminjaman(String statusFilter) {

        SQLiteDatabase db = this.getReadableDatabase();

        String query =
                "SELECT anggota.nama, anggota.telepon, anggota.kelas, buku.judul, " +
                        "peminjaman.tanggal_pinjam, peminjaman.tanggal_kembali, peminjaman.status " +
                        "FROM peminjaman " +
                        "JOIN anggota ON peminjaman.id_anggota = anggota.id " +
                        "JOIN buku ON peminjaman.id_buku = buku.id";

        if (statusFilter != null && !statusFilter.equals("Semua")) {
            query += " WHERE peminjaman.status = ? ORDER BY peminjaman.id DESC";
            return db.rawQuery(query, new String[]{statusFilter});
        }

        query += " ORDER BY peminjaman.id DESC";
        return db.rawQuery(query, null);
    }

    // FIX: dulu cuma ubah kolom status ("Dipinjam" <-> "Dikembalikan") tanpa
    // menyentuh stok buku sama sekali. Sekarang:
    // - tandai "Dikembalikan" -> stok buku ditambah 1
    // - tandai ulang jadi "Dipinjam" (mis. salah pencet) -> stok buku dikurangi 1
    //   lagi (dicek dulu stoknya cukup atau tidak)
    // Kalau status barunya sama dengan status lama, tidak ada perubahan stok
    // (supaya tidak dobel nambah/kurang kalau tombol dipencet berkali-kali).
    public boolean updateStatusPeminjaman(String id, String statusBaru) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            String idBuku = null;
            String statusLama = null;
            Cursor c = db.rawQuery("SELECT id_buku, status FROM peminjaman WHERE id=?", new String[]{id});
            if (c.moveToFirst()) {
                idBuku = c.getString(0);
                statusLama = c.getString(1);
            }
            c.close();

            if (idBuku == null) {
                return false; // data peminjaman tidak ditemukan
            }

            if (statusBaru.equals("Dipinjam") && !statusBaru.equals(statusLama)) {
                int stok = getStokDalamTransaksi(db, idBuku);
                if (stok <= 0) {
                    return false; // stok habis, tidak bisa ditandai dipinjam lagi
                }
            }

            ContentValues cvStatus = new ContentValues();
            cvStatus.put("status", statusBaru);
            int hasilStatus = db.update("peminjaman", cvStatus, "id=?", new String[]{id});
            if (hasilStatus <= 0) {
                return false;
            }

            if (!statusBaru.equals(statusLama)) {
                int stokSekarang = getStokDalamTransaksi(db, idBuku);
                int stokBaru = statusBaru.equals("Dikembalikan") ? stokSekarang + 1 : stokSekarang - 1;

                ContentValues cvStok = new ContentValues();
                cvStok.put("stok", stokBaru);
                db.update("buku", cvStok, "id=?", new String[]{idBuku});
            }

            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }

    // FIX: edit data peminjaman sekarang juga menyesuaikan stok buku kalau buku
    // yang dipinjam diganti selagi statusnya masih "Dipinjam": stok buku LAMA
    // dikembalikan (+1), stok buku BARU dikurangi (-1). Kalau buku pengganti
    // ternyata stoknya habis, seluruh perubahan dibatalkan (rollback).
    public boolean updatePeminjaman(String id, String idBukuBaru, String idAnggota, String tglPinjam, String tglKembali, String status) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            String idBukuLama = null;
            Cursor c = db.rawQuery("SELECT id_buku FROM peminjaman WHERE id=?", new String[]{id});
            if (c.moveToFirst()) {
                idBukuLama = c.getString(0);
            }
            c.close();

            boolean bukuBerubah = "Dipinjam".equals(status)
                    && idBukuLama != null
                    && !idBukuLama.equals(idBukuBaru);

            if (bukuBerubah) {
                int stokBukuBaru = getStokDalamTransaksi(db, idBukuBaru);
                if (stokBukuBaru <= 0) {
                    return false; // buku pengganti stoknya habis, batal edit
                }
            }

            ContentValues cv = new ContentValues();
            cv.put("id_buku", idBukuBaru);
            cv.put("id_anggota", idAnggota);
            cv.put("tanggal_pinjam", tglPinjam);
            cv.put("tanggal_kembali", tglKembali);
            cv.put("status", status);
            int hasil = db.update("peminjaman", cv, "id=?", new String[]{id});
            if (hasil <= 0) {
                return false;
            }

            if (bukuBerubah) {
                int stokLama = getStokDalamTransaksi(db, idBukuLama);
                ContentValues cvLama = new ContentValues();
                cvLama.put("stok", stokLama + 1);
                db.update("buku", cvLama, "id=?", new String[]{idBukuLama});

                int stokBaru = getStokDalamTransaksi(db, idBukuBaru);
                ContentValues cvBaru = new ContentValues();
                cvBaru.put("stok", stokBaru - 1);
                db.update("buku", cvBaru, "id=?", new String[]{idBukuBaru});
            }

            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }

    // FIX: kalau data peminjaman yang dihapus statusnya masih "Dipinjam" (belum
    // dikembalikan), stok bukunya dikembalikan (+1) juga. Kalau tidak, buku itu
    // akan "hilang" dari stok selamanya walau catatan peminjamannya sudah hapus.
    // Kalau statusnya sudah "Dikembalikan", stok tidak diutak-atik lagi (sudah
    // dikembalikan duluan waktu ditandai selesai).
    public boolean deletePeminjaman(String id) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            String idBuku = null;
            String status = null;
            Cursor c = db.rawQuery("SELECT id_buku, status FROM peminjaman WHERE id=?", new String[]{id});
            if (c.moveToFirst()) {
                idBuku = c.getString(0);
                status = c.getString(1);
            }
            c.close();

            int hasilDelete = db.delete("peminjaman", "id=?", new String[]{id});
            if (hasilDelete <= 0) {
                return false;
            }

            if (idBuku != null && "Dipinjam".equals(status)) {
                int stok = getStokDalamTransaksi(db, idBuku);
                ContentValues cv = new ContentValues();
                cv.put("stok", stok + 1);
                db.update("buku", cv, "id=?", new String[]{idBuku});
            }

            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }
}